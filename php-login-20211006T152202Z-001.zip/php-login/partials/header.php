<header>
  <a href="/php-login">Nuestra pagina web</a>
</header>
<?
require 'database.php';
?>